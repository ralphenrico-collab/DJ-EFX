package com.ralphenrico.djefx;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.media.AudioManager;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout grid;
    float master = 0.8f;
    final String[] names = {"AIR HORN","SIREN","DJ DROP","HYPE","APPLAUSE","DRUM ROLL",
            "STUTTER","REVERSE","PARTY","HEY!","LASER","RISER","BOOM","BEEP","SCRATCH","GO!"};

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setVolumeControlStream(AudioManager.STREAM_MUSIC);
        build();
    }

    void build() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(12,8,12,8);
        root.setBackgroundColor(Color.rgb(9,9,9));

        TextView title = new TextView(this);
        title.setText("DJ EFX  •  RALPH");
        title.setTextColor(Color.WHITE);
        title.setTextSize(24);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null,1);
        root.addView(title,new LinearLayout.LayoutParams(-1,55));

        LinearLayout controls = new LinearLayout(this);
        Button stop = button("■  STOP ALL");
        stop.setBackgroundColor(Color.rgb(175,0,30));
        controls.addView(stop,new LinearLayout.LayoutParams(0,58,1));
        SeekBar vol = new SeekBar(this);
        vol.setProgress(80);
        controls.addView(vol,new LinearLayout.LayoutParams(0,58,1));
        root.addView(controls);

        stop.setOnClickListener(v -> Toast.makeText(this,"ALL FX STOPPED",Toast.LENGTH_SHORT).show());
        vol.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar s,int p,boolean f){master=p/100f;}
            public void onStartTrackingTouch(SeekBar s){}
            public void onStopTrackingTouch(SeekBar s){}
        });

        grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        String[][] rows = new String[4][4];
        for(int i=0;i<16;i++) rows[i/4][i%4]=names[i];

        for(String[] row: rows){
            LinearLayout r=new LinearLayout(this);
            for(String n:row){
                Button p=button(n);
                r.addView(p,new LinearLayout.LayoutParams(0,0,1));
                p.setOnClickListener(v -> fx(n));
            }
            grid.addView(r,new LinearLayout.LayoutParams(-1,0,1));
        }
        root.addView(grid,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }

    Button button(String text){
        Button b=new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(12);
        b.setAllCaps(false);
        b.setBackgroundColor(Color.rgb(25,25,25));
        b.setPadding(4,4,4,4);
        return b;
    }

    void fx(String n){
        Toast.makeText(this,n+"  •  FX",Toast.LENGTH_SHORT).show();
        // Sound sample playback can be connected here to your own MP3/WAV files.
    }
}