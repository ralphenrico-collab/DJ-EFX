DJ EFX Android Project — Ralph Enrico

This is the native Android project for the DJ EFX sampler.
Target: Android 6.0+.
Orientation: landscape.
Name: DJ EFX • RALPH.
Layout: 16 large pads + master volume + STOP ALL.

Important:
This source project is ready to open/build in Android Studio. A directly installable signed APK still needs to be compiled and signed by an Android build environment.
The next implementation step is connecting each pad to actual MP3/WAV sample files and adding a file picker so samples can be assigned from the phone.
