DJ EFX V4 • RALPH
Portrait-safe responsive soundboard. 4x6 pads, no ads, audio loading, saved pad assignments.
V4 fixes Android status/navigation bar overlap and fits the pad grid + bottom controls to the available screen.
