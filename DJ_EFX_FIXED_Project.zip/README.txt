DJ EFX Android project — corrected Gradle structure.
This project is intended to be built by GitHub Actions into app-debug.apk.
Current UI is the sampler shell; actual MP3/WAV assignment/playback is the next feature.
