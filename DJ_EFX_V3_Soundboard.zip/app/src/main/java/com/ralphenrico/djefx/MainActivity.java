package com.ralphenrico.djefx;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    final int N=24, PICK=901;
    final String[] names={
        "AIR HORN","SIREN","DJ DROP","HYPE",
        "APPLAUSE","DRUM ROLL","STUTTER","REVERSE",
        "PARTY","HEY!","LASER","RISER",
        "BOOM","BEEP","SCRATCH","WHISTLE",
        "FANFARE","WOO","IMPACT","GO!",
        "CLAP","BASS HIT","DANCE","FX"
    };
    final int[] colors={
        0xff315fa8,0xffad292d,0xff23a52a,0xffb6a21f,
        0xffaa5a27,0xff5726a5,0xff2aa4a5,0xffa627a5
    };
    Button[] pads=new Button[N];
    MediaPlayer[] players=new MediaPlayer[N];
    SharedPreferences pref;
    TextView status;
    int selected=-1, editing=-1;
    SeekBar volume;

    int d(float x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}

    GradientDrawable shape(int color){
        GradientDrawable g=new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(d(12));
        return g;
    }

    TextView label(String s,float size){
        TextView t=new TextView(this);
        t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(size);
        return t;
    }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        pref=getSharedPreferences("soundboard",0);
        build();
    }

    void build(){
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(d(7),d(4),d(7),0);
        root.setBackgroundColor(Color.BLACK);

        LinearLayout header=new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title=label("DJ EFX  •  RALPH",24);
        title.setTypeface(null,Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        header.addView(title,new LinearLayout.LayoutParams(0,d(52),1));

        Button menu=new Button(this);
        menu.setText("⋮");
        menu.setTextColor(Color.WHITE);
        menu.setTextSize(24);
        menu.setBackgroundColor(Color.TRANSPARENT);
        menu.setOnClickListener(v->showMenu(menu));
        header.addView(menu,new LinearLayout.LayoutParams(d(48),d(52)));
        root.addView(header);

        status=label("TAP = PLAY   •   HOLD = CHANGE SOUND",10);
        status.setGravity(Gravity.CENTER);
        status.setTextColor(0xffaaaaaa);
        root.addView(status,new LinearLayout.LayoutParams(-1,d(26)));

        volume=new SeekBar(this);
        volume.setProgress(pref.getInt("volume",85));
        root.addView(volume,new LinearLayout.LayoutParams(-1,d(30)));

        GridLayout grid=new GridLayout(this);
        grid.setColumnCount(4);
        grid.setRowCount(6);

        for(int i=0;i<N;i++){
            final int x=i;
            Button b=new Button(this);
            pads[i]=b;
            b.setAllCaps(false);
            b.setTextSize(12);
            b.setTextColor(Color.WHITE);
            b.setGravity(Gravity.CENTER);
            b.setPadding(d(2),d(2),d(2),d(2));
            updatePad(i);
            GridLayout.LayoutParams lp=new GridLayout.LayoutParams();
            lp.width=0; lp.height=d(82);
            lp.columnSpec=GridLayout.spec(i%4,1f);
            lp.rowSpec=GridLayout.spec(i/4);
            lp.setMargins(d(3),d(3),d(3),d(3));
            grid.addView(b,lp);
            b.setOnClickListener(v->{
                selected=x;
                play(x);
            });
            b.setOnLongClickListener(v->{editing=x; pickAudio(); return true;});
        }

        ScrollView scroll=new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(grid);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout bottom=new LinearLayout(this);
        bottom.setPadding(0,d(3),0,d(2));

        Button stop=bottomButton("■\nStop");
        Button load=bottomButton("↓\nLoad");
        Button clear=bottomButton("▣\nClear");
        Button reset=bottomButton("↻\nReset");

        bottom.addView(stop,new LinearLayout.LayoutParams(0,d(62),1));
        bottom.addView(load,new LinearLayout.LayoutParams(0,d(62),1));
        bottom.addView(clear,new LinearLayout.LayoutParams(0,d(62),1));
        bottom.addView(reset,new LinearLayout.LayoutParams(0,d(62),1));

        stop.setOnClickListener(v->stopAll());
        load.setOnClickListener(v->{
            if(selected<0) selected=0;
            editing=selected;
            pickAudio();
        });
        clear.setOnClickListener(v->{
            if(selected>=0){
                pref.edit().remove("uri"+selected).remove("name"+selected).apply();
                updatePad(selected);
                status.setText("Pad "+(selected+1)+" cleared");
            }else status.setText("Tap a pad first, then Clear");
        });
        reset.setOnClickListener(v->resetAll());

        root.addView(bottom);
        setContentView(root);

        volume.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar s,int p,boolean f){
                pref.edit().putInt("volume",p).apply();
                for(MediaPlayer m:players) if(m!=null) m.setVolume(p/100f,p/100f);
            }
            public void onStartTrackingTouch(SeekBar s){}
            public void onStopTrackingTouch(SeekBar s){}
        });
    }

    Button bottomButton(String s){
        Button b=new Button(this);
        b.setText(s);
        b.setTextColor(Color.WHITE);
        b.setTextSize(11);
        b.setAllCaps(false);
        b.setBackgroundColor(Color.BLACK);
        return b;
    }

    void updatePad(int i){
        boolean has=pref.contains("uri"+i);
        String n=pref.getString("name"+i,names[i]);
        pads[i].setText((has?"▶ ":"")+n);
        pads[i].setBackground(shape(colors[i%colors.length]));
    }

    void pickAudio(){
        Intent in=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        in.addCategory(Intent.CATEGORY_OPENABLE);
        in.setType("audio/*");
        in.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(in,PICK);
    }

    @Override protected void onActivityResult(int r,int c,Intent data){
        super.onActivityResult(r,c,data);
        if(r==PICK && c==RESULT_OK && data!=null && editing>=0){
            Uri u=data.getData();
            try{getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception e){}
            String n=u.getLastPathSegment();
            if(n==null)n="CUSTOM FX";
            if(n.length()>20)n=n.substring(0,20);
            pref.edit().putString("uri"+editing,u.toString()).putString("name"+editing,n).apply();
            updatePad(editing);
            selected=editing;
            status.setText("Loaded: "+n);
            editing=-1;
        }
    }

    void play(int i){
        String s=pref.getString("uri"+i,null);
        if(s==null){
            editing=i;
            pickAudio();
            return;
        }
        stop(i);
        try{
            MediaPlayer m=MediaPlayer.create(this,Uri.parse(s));
            if(m==null)throw new Exception();
            float v=volume.getProgress()/100f;
            m.setVolume(v,v);
            players[i]=m;
            m.setOnCompletionListener(q->{q.release();players[i]=null;});
            m.start();
            status.setText("PLAYING: "+pref.getString("name"+i,names[i]));
        }catch(Exception e){
            status.setText("Can't play • HOLD pad to reload");
        }
    }

    void stop(int i){
        if(players[i]!=null){
            try{players[i].stop();}catch(Exception e){}
            players[i].release();
            players[i]=null;
        }
    }

    void stopAll(){
        for(int i=0;i<N;i++)stop(i);
        status.setText("ALL SOUNDS STOPPED");
    }

    void resetAll(){
        stopAll();
        pref.edit().clear().apply();
        selected=-1;
        volume.setProgress(85);
        for(int i=0;i<N;i++)updatePad(i);
        status.setText("RESET COMPLETE");
    }

    void showMenu(View anchor){
        PopupMenu pm=new PopupMenu(this,anchor);
        pm.getMenu().add("About DJ EFX");
        pm.getMenu().add("How to use");
        pm.getMenu().add("No ads • Offline");
        pm.setOnMenuItemClickListener(item->{
            new AlertDialog.Builder(this)
                .setTitle(item.getTitle())
                .setMessage(item.getTitle().toString().equals("How to use")?
                    "Tap an empty pad to load a sound. Tap a loaded pad to play. Long-press any pad to change its sound. Select a pad then use Load/Clear. Your assignments are saved on this phone."
                    :"DJ EFX • Ralph\\nPersonal soundboard sampler\\nNo advertisements.")
                .setPositiveButton("OK",null).show();
            return true;
        });
        pm.show();
    }

    @Override protected void onDestroy(){
        stopAll();
        super.onDestroy();
    }
}
