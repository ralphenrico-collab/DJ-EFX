DJ EFX V3 Soundboard — Portrait, no advertisements.

Style: 4-column x 6-row colorful soundboard, 24 pads, bottom Stop/Load/Clear/Reset controls.
Tap empty pad: choose audio. Tap loaded pad: play. Long press: change sound.
Assignments are saved locally on the Android phone.
No advertising SDK or ad banner is included.
